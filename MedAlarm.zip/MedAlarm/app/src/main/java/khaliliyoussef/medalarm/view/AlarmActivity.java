package khaliliyoussef.medalarm.view;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import khaliliyoussef.medalarm.R;
import khaliliyoussef.medalarm.data.User;


public class AlarmActivity extends AppCompatActivity {

    private static final String TAG = "AlarmActivity.class";

    Button alarmYesbtn;
    Button alarmNobtn;
    String userId;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        initializeToolBar();


        
        // Log.d("Firebase", "token " + FirebaseInstanceId.getInstance().getToken());
        alarmYesbtn= (Button) findViewById(R.id.alarm_yes_btn);
        alarmYesbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do nothing or set notify= false;

                FirebaseDatabase.getInstance().getReference().child("users").child(userId).child("notify").setValue(false);
                Log.d(TAG, "onClick: yes btn" );

            }
        });
        alarmNobtn = (Button) findViewById(R.id.alarm_no_btn);
        alarmNobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference followerRef;
                 followerRef = FirebaseDatabase.getInstance().getReference().child("users").child(user.getFollowerId()).child("notify");
                followerRef.setValue(true);


            }
        });

    }



    @Override
    protected void onStart() {
        super.onStart();
        onCheckCurrentUserStatus();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == R.id.menu_logout) {
            onLogoutCurrentUser();
        }
        else if (item.getItemId()==R.id.menu_add_follower)
        {
            Intent intent=new Intent(this,AddFollowerActivity.class);
            startActivity(intent);
        }
        return true;
    }

    // Initiating Menu XML file (menu.xml)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.alarm_menu, menu);
        return true;
    }
//initialize the toolbar on the screen
    private void initializeToolBar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_alarm);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }
    }

    private void onCheckCurrentUserStatus() {
        //get the current user (null -->it doesn't exist)
        FirebaseUser currentUser =FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {//it's not signed in
            Intent startIntent = new Intent(this, StartActivity.class);
            startActivity(startIntent);
            //we use finish so that hen he press back button he won't come back to this activity
            finish();

        }
        else
        {
            userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            Log.i(TAG, "onCheckCurrentUserStatus: "+userId);
            onCheckNotify();
        }
    }

    private void onLogoutCurrentUser() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, StartActivity.class);
        startActivity(intent);
        finish();
    }


    private void generateFollowerNotification() {

        //when he press on the content of the notification go somewhere "MainActivity"
        Intent intent = new Intent(getApplicationContext(), AlarmActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder b = new NotificationCompat.Builder(getApplicationContext());


//adds a button to the notification
        Intent yIntent = new Intent();
        PendingIntent yPendingIntent = PendingIntent.getActivity(this, 1, yIntent, PendingIntent.FLAG_ONE_SHOT);

        //Button
        NotificationCompat.Action yAction = new NotificationCompat.Action.Builder(R.mipmap.ic_launcher, "Don't notify again", yPendingIntent).build();

        Uri notificationSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Resources res = AlarmActivity.this.getResources();
        b.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setSound(notificationSoundUri)
                .setSmallIcon(R.drawable.progress_circle)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.ic_sync_black_24dp))
                .setTicker("Follower Alert")
                .setContentTitle("Follower Medication")
                .setContentText("the patient you are following forgotten to take his medication")
                .setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_SOUND)
                .setContentIntent(contentIntent)
                .addAction(yAction)
                .setContentInfo("Info");


        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1, b.build());
    }
    private void createNewNotification() {
        int YOUR_NOTIF_ID = 1245;
        int YOUR_PI_REQ_CODE = 551;
        Intent notificationIntent = new Intent(AlarmActivity.this, AlarmActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(AlarmActivity.this,
                YOUR_PI_REQ_CODE, notificationIntent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationManager nm = (NotificationManager) getApplicationContext()
                .getSystemService(Context.NOTIFICATION_SERVICE);

        Resources res = AlarmActivity.this.getResources();
        Notification.Builder builder = new Notification.Builder(getApplicationContext());

        builder.setContentIntent(contentIntent)
                .setSmallIcon(R.drawable.progress_circle)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.ic_sync_black_24dp))
                .setTicker(res.getString(R.string.your_ticker))
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true)
                .setContentTitle(res.getString(R.string.your_notif_title))
                .setContentText(res.getString(R.string.your_notif_text));
        Notification n = builder.build();

        nm.notify(YOUR_NOTIF_ID, n);
    }

    private void onCheckNotify() {


        DatabaseReference noty = FirebaseDatabase.getInstance().getReference().child("users").child(userId);
        noty.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                user = dataSnapshot.getValue(User.class);
              userId=dataSnapshot.getKey();
                   if (user.isNotify()) {
                       //createNewNotification();
                       generateFollowerNotification();
                   }

                   Toast.makeText(AlarmActivity.this, "notify value :" + user.isNotify(), Toast.LENGTH_LONG).show();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }



}
